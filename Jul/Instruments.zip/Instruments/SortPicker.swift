//
//  SortPicker.swift
//  Jul
//
//  Created by Julia on 11.05.2025.
//


import SwiftUI

struct SortPicker: View {
    @Binding var selection: String
    let sortOptions: [String]

    var body: some View {
        Picker("Sort by:", selection: $selection) {
            ForEach(sortOptions, id: \.self) { option in
                Text(option).tag(option)
            }
        }
        .pickerStyle(MenuPickerStyle())
    }
}
