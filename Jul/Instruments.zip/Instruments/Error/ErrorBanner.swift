//
//  ErrorBanner.swift
//  Jul
//
//  Created by Julia on 10.05.2025.
//
import SwiftUI

struct ErrorBanner: View {
    let message: String?

    var body: some View {
        if let msg = message {
            Text(msg)
                .font(.caption)
                .foregroundColor(.white)
                .padding(8)
                .background(Color.red.cornerRadius(6))
                .transition(.opacity)
                .animation(.easeInOut, value: msg)
        }
    }
}
