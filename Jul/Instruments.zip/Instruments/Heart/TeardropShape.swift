//
//  DropShape.swift
//  Jul
//
//  Created by Julia on 14.05.2025.
//
import SwiftUI

struct TeardropShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()

        let width = rect.width
        let height = rect.height

        let topOffset: CGFloat = height * 0.01

        path.move(to: CGPoint(x: width / 2, y: topOffset)) // верхний острый конец


        // Левая сторона
        path.addQuadCurve(to: CGPoint(x: 0, y: height),
                          control: CGPoint(x: -width * 0.5, y: height * 0.6))

        // Низ
        path.addQuadCurve(to: CGPoint(x: width, y: height),
                          control: CGPoint(x: width / 2, y: height * 1.3))

        // Правая сторона (зеркальная копия левой)
        path.addQuadCurve(to: CGPoint(x: width / 2, y: topOffset),
                          control: CGPoint(x: width * 1.5, y: height * 0.6))

        return path
    }
}
