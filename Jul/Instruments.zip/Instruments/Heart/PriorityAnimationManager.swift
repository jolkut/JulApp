//
//  PriorityAnimationManager.swift
//  Jul
//
//  Created by Julia on 14.05.2025.
//
import SwiftUI

class PriorityAnimationManager: ObservableObject {
    @Published var showHeart = false
    @Published var isAdding = false
    @Published var origin: CGRect = .zero

    // Новый цвет для текущего состояния
    @Published var currentColor: Color = .white

    func trigger(isAdding: Bool, from rect: CGRect) {
        self.isAdding = isAdding
        self.origin = rect
        self.currentColor = isAdding ? .white : .red // начальный цвет
        self.showHeart = true
    }

    func reset() {
        self.showHeart = false
    }
}
