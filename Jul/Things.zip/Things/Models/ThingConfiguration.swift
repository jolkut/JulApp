





import Foundation
import SwiftData


@Model
class ThingConfiguration {
    var id: UUID
    var configuration: String
    var image: Data // <- Changed from String to Data

    init(configuration: String, image: Data) {
        self.id = UUID()
        self.configuration = configuration
        self.image = image
    }
}
