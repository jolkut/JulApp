//
//  StoreThing.swift
//  Jul
//
//  Created by Julia on 26.04.2025.
//


import Foundation
import SwiftData

@Model
class StoreThing {
    var id: String { title }
    var title: String
    
    // Добавляем инициализатор
    init(title: String) {
        self.title = title
    }
}